# Running visualization
```
import Main;
main();
```

# Running report
Uncomment printReportToFile(`<PROJECT>`)

```
import Main;
main();
```